// Array of books
const books = [
    { id: 1, title: "To Kill a Mockingbird", author: "Harper Lee", genre: "Fiction" },
    { id: 2, title: "A Brief History of Time", author: "Stephen Hawking", genre: "Science" },
    { id: 3, title: "1984", author: "George Orwell", genre: "Fiction" },
    { id: 4, title: "The Great Gatsby", author: "F. Scott Fitzgerald", genre: "Fiction" },
    { id: 5, title: "Sapiens", author: "Yuval Noah Harari", genre: "Non-Fiction" }
];

// Login credentials
const validUsername = "Virtual Library Hub";
const validPassword = "12345";

// Borrowed books
let borrowedBooks = [];

// Login validation
document.getElementById("login-form").addEventListener("submit", function (event) {
    event.preventDefault();

    const username = document.getElementById("username").value;
    const password = document.getElementById("password").value;

    if (username === validUsername && password === validPassword) {
        document.getElementById("login-page").style.display = "none";
        document.getElementById("library-page").style.display = "block";
    } else {
        document.getElementById("error-message").style.display = "block";
    }
});

// Search books
function searchBooks() {
    const query = document.getElementById("search-bar").value.toLowerCase();
    const results = books.filter(book =>
        book.title.toLowerCase().includes(query) ||
        book.author.toLowerCase().includes(query) ||
        book.genre.toLowerCase().includes(query)
    );

    const resultsDiv = document.getElementById("search-results");
    resultsDiv.innerHTML = results.length
        ? results.map(book => `<li><strong>${book.title}</strong> by ${book.author} (${book.genre})</li>`).join("")
        : "<li>No books found</li>";
}

// Borrow book
function borrowBook() {
    const bookId = parseInt(document.getElementById("book-id").value);
    if (!bookId) return alert("Please enter a valid Book ID!");

    const book = books.find(b => b.id === bookId);

    if (book && !borrowedBooks.includes(bookId)) {
        borrowedBooks.push(bookId);
        alert(`You borrowed "${book.title}"`);
        displayBorrowedBooks();
    } else {
        alert(book ? `You already borrowed "${book.title}"` : "Invalid Book ID!");
    }
}

// Return book
function returnBook() {
    const bookId = parseInt(document.getElementById("book-id").value);
    if (!bookId) return alert("Please enter a valid Book ID!");

    const book = books.find(b => b.id === bookId);

    if (book && borrowedBooks.includes(bookId)) {
        borrowedBooks = borrowedBooks.filter(id => id !== bookId);
        alert(`You returned "${book.title}"`);
        displayBorrowedBooks();
    } else {
        alert(book ? `You have not borrowed "${book.title}"` : "Invalid Book ID!");
    }
}

// Display borrowed books
function displayBorrowedBooks() {
    const list = document.getElementById("borrowed-books-list");
    list.innerHTML = borrowedBooks
        .map(id => `<li>${books.find(b => b.id === id).title}</li>`)
        .join("");
}

// Submit review
function submitReview() {
    const rating = document.getElementById("rating").value;
    const review = document.getElementById("review-text").value;

    if (rating < 1 || rating > 5 || !review.trim()) {
        alert("Please provide a valid rating (1-5) and review.");
        return;
    }

    const reviewList = document.getElementById("reviews-list");
    reviewList.innerHTML += `<li><strong>Rating:</strong> ${rating}<br>${review}</li>`;
    alert("Review submitted successfully!");
}
